import React, { useState } from 'react';
import { Primarybtt } from './button';

export default function Input_add(){
    const [value,setValue] = useState('')
    const [notes,setNotes] = useState([]);
    const addnote = (e) => {
        if(value.trim()){
            setNotes(prev => (
                [...prev,
                {value: value.trim(),
                id: notes.length+value.trim().substr(0,1),
                key: notes.length+value.trim().substr(0,1)}]
                ))
        }
        setValue('')
    }
    
    const removenote = (e) => {
        setNotes(prev => (
            notes.filter(item => item.id !== e.target.parentElement.id) 
            ))
    }

    const handlli = (e) => {
        if(e.target.parentElement.tagName !== 'UL'){
            e.target.parentElement.classList.add('line-through')
        }
    }

    return(
        <div>
            <input className='form-control' onChange={e => {setValue(e.target.value)}} value={value}/>
            <Primarybtt onclick={addnote} value='Add'/>
            <hr/>
            <ul className='list-group'>{notes.map(item => <li key={item.key} id={item.id} onClick={handlli} className='list-group-item'><strong>{item.value}</strong>
            <Primarybtt onclick={removenote} value='click'/>

            </li>)}</ul>
        </div>
    )
}