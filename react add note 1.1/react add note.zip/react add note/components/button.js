import React from 'react';

export const Primarybtt = ({onclick,value}) => {
    return(
        <button className='btn-primary' onClick={onclick}>{value}</button>
    )
}