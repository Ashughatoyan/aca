import React from 'react'
import ReactDOM from 'react-dom';
import Input_add from './components/input_add';


function App() {
  return (
    <React.Fragment>
      <Input_add/>
    </React.Fragment>
  );
}

export default App